package mx.tecnm.tepic.ladm_u3_practica2_erickcuriel

import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteException
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    //SQLite
    var baseDatos = BaseDatos(this, "CITA", null, 1)

    var listaID          =   ArrayList<String>()
    var datos            =   ArrayList<String>()
    var datosAuxiliar    =   ArrayList<String>()

    var idSeleccionadoEnLista = -1
    //ConexionFireBase
    var baseRemota = FirebaseFirestore.getInstance()
    var id = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            insertar()
            insertarFirebase()
        }

        button2.setOnClickListener {
            consultar()
        }

        button3.setOnClickListener {
            sincronizar()
        }
        cargarCitas()
    }

    override fun onResume() {
        super.onResume()
        cargarCitas()
    }



    private fun consultar() {
        try {
            var trans = baseDatos.readableDatabase

            var resultados = trans.query(
                "CITA", arrayOf(
                    "IDC",
                    "LUGAR",
                    "HORA",
                    "FECHA",
                    "DESCRIPCION"
                ), "IDC=?", arrayOf(editTextIDC.text.toString()), null, null, null, null
            )

            if (resultados.moveToFirst()) {
                var cadena =    "IDC: "           +   resultados.getInt(0)        +
                                "\nLUGAR: "       +   resultados.getString(1)     +
                                "\nHORA: "        +   resultados.getString(2)     +
                                "\nFECHA: "       +   resultados.getString(3)     +
                                "\nDESCRIPCION: " +   resultados.getString(4)

                mensaje(cadena)
            } else {
                mensaje("NO SE ENCONTRARON RESULTADOS")
            }
            trans.close()

        } catch (e: SQLiteException) {

        }
    }

    //InsercionSQLite
    private fun insertar(){
        try{
            var trans = baseDatos.writableDatabase
            var variables = ContentValues()
            //HORA, FECHA, DESCRIPCION
            variables.put("IDC", editTextIDC.text.toString().toInt())
            variables.put("LUGAR", editTextLugar.text.toString())
            variables.put("HORA", editTextHora.text.toString())
            variables.put("FECHA", editTextFecha.text.toString())
            variables.put("DESCRIPCION", editTextDescripcion.text.toString())

            var respuesta = trans.insert("CITA", null, variables)
            if (respuesta == -1L) {
                mensaje("ERROR NO SE PUDO INSERTAR")
            } else {
                mensaje("SE INSERTÓ CON EXITO")
            }
            trans.close()

        } catch (e: SQLiteException) {
            mensaje(e.message!!)
        }
        cargarCitas()
    }


    //InsercionFirebase
    private fun insertarFirebase(){
        //Prueba Borrado Coleccion
        //baseRemota.

            var datosInsertar = hashMapOf(
                "IDC"           to editTextIDC.text.toString(),
                "LUGAR"         to editTextLugar.text.toString(),
                "HORA"          to editTextHora.text.toString(),
                "FECHA"         to editTextFecha.text.toString(),
                "DESCRIPCION"   to editTextDescripcion.text.toString()
            )

            baseRemota.collection("CITA")
                .add(datosInsertar as Any)
                .addOnSuccessListener {
                    // Se ejecuta en caso de la que la transaccion sea exitosa
                    Toast.makeText(this, "Se inserto correctamente con IDC ${it.id}", Toast.LENGTH_LONG).show()
                    limpiarCampos()
                }
                .addOnFailureListener{
                    //Se ejecuta en caso de ERROR
                    mensaje("No se pudo insertar: \n${it.message!!}")
                }

    }

    private fun sincronizar(){
        datosAuxiliar.clear()
        baseRemota.collection("CITA").addSnapshotListener { querySnapshot, firebaseFirestoreException ->
            if (firebaseFirestoreException != null) {                                                       //Busqueda base de datos
                mensaje("Error en la sincronización")
                return@addSnapshotListener
            }

            var cita = ""

            for (registro in querySnapshot!!) {
                cita = registro.id.toString()                                                               //Llenado registros datos auxiliar
                datosAuxiliar.add(cita)
            }

            try {
                var trans = baseDatos.readableDatabase                                                      //Lectura datos locales
                var respuesta = trans.query("CITA", arrayOf("*"), null, null, null, null, null)

                if (respuesta.moveToFirst()) {

                    do{
                        baseRemota.waitForPendingWrites()                                                   //Cola de lecturas

                        if (datosAuxiliar.any{respuesta.getString(0).toString() == it}) {                   //Consulta registros

                            datosAuxiliar.remove(respuesta.getString(0).toString())
                            baseRemota.collection("CITA")
                                .document(respuesta.getString(0))
                                .update("DESCRIPCION",  respuesta.getString(1),
                                        "LUGAR",        respuesta.getString(2),                             //Insercion base de datos remota
                                        "FECHA",        respuesta.getString(3),
                                        "HORA",         respuesta.getString(4)
                                ).addOnSuccessListener {
                                    baseRemota.waitForPendingWrites()                                       //Cola de lecturas
                                }.addOnFailureListener {
                                    AlertDialog.Builder(this)
                                        .setTitle("AVISO")
                                        .setMessage("ERROR AL ACTUALIZAR: \n${it.message!!}")
                                        .setPositiveButton("Ok"){d,i->}
                                        .show()
                                }
                        } else {
                            var datosInsertar = hashMapOf(
                                "DESCRIPCION"   to respuesta.getString(1),
                                "LUGAR"         to respuesta.getString(2),                                  //Insercion datos
                                "FECHA"         to respuesta.getString(3),
                                "HORA"          to respuesta.getString(4)
                            )
                            baseRemota.collection("CITA").document("${respuesta.getString(0)}")             //Envio de datos 
                                .set(datosInsertar as Any).addOnSuccessListener {
                                }
                                .addOnFailureListener {
                                    mensaje("ERROR AL INSERTAR:\n${it.message!!}")
                                }
                        }
                    }while (respuesta.moveToNext())

                } else {
                    datos.add("BASE DE DATOS VACIA")
                }
                trans.close()
            } catch (e: SQLiteException) {
                mensaje("ERROR: " + e.message!!)
            }
            var eliminar = datosAuxiliar.subtract(listaID)
            if (eliminar.isEmpty()) {

            } else {
                eliminar.forEach {
                    baseRemota.collection("CITA")
                        .document(it)
                        .delete()
                        .addOnSuccessListener {}
                        .addOnFailureListener { mensaje("Error al eliminar: \n" + it.message!!) }
                }
            }

        }
            mensaje("Sincronizacion Completada")
    }


    private fun cargarCitas(){
        try{
            var trans = baseDatos.readableDatabase
            var citas = ArrayList<String>()
            var respuesta = trans.query("CITA", arrayOf("*"), null, null, null, null, null)

            listaID.clear()

            if (respuesta.moveToFirst()) {
                do {
                    var concatenacion = "IDC:   ${respuesta.getInt(0)}         \n"+
                                        "LUGAR: ${respuesta.getString(1)}      \n"+
                                        "HORA:  ${respuesta.getString(2)}      \n"+
                                        "FECHA: ${respuesta.getString(3)}      \n"+
                                        "DESCRIPCION: ${respuesta.getString(4)}\n"
                    citas.add(concatenacion)
                    listaID.add(respuesta.getInt(0).toString())
                } while (respuesta.moveToNext())

            } else {
                citas.add("NO HAY CITAS INSERTADOS")
            }

            listaCitas.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, citas)

            // ligando menuppal con listaContactos
            this.registerForContextMenu(listaCitas)

            listaCitas.setOnItemClickListener { adapterView, view, i, l ->
                idSeleccionadoEnLista = i
                Toast.makeText(this, "Se seleccionó elemento", Toast.LENGTH_LONG)
                    .show()
            }
            trans.close()

        } catch (e: SQLiteException) {
        mensaje("ERROR: " + e.message!!)
        }
    }

    private fun eliminar(idEliminar: String) {
        try {
            var trans       = baseDatos.writableDatabase
            var registros   = trans

            var resultado = trans.delete("CITA", "IDC=?", arrayOf(idEliminar))

            if (resultado == 0){
                mensaje("ERROR! NO SE PUDO ELIMINAR!!")
            } else {
                mensaje("SE LOGRO ELIMINAR CON EXITO EL IDC ${idEliminar}")
            }
            trans.close()
            cargarCitas()
        } catch (e: SQLiteException) {
            mensaje(e.message!!)
        }
    }



    private fun limpiarCampos() {
        editTextIDC.setText("")
        editTextLugar.setText("")
        editTextHora.setText("")
        editTextFecha.setText("")
        editTextDescripcion.setText("")
    }

    private fun mensaje(s: String) {
        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage(s)
            .setPositiveButton("Ok") { d, i -> d.dismiss()}
            .show()
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        var inflaterOB = menuInflater

        inflaterOB.inflate(R.menu.menuppal, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        if (idSeleccionadoEnLista == -1) {
            mensaje("ERROR! Debes dar clic primero en un Item para ACTUALIZAR/BORRAR")
            return true
        }

        when (item.itemId) {
            R.id.itemactualizar -> {
                var ventana = Intent(this, MainActivity2::class.java)

                ventana.putExtra("idactualizar", listaID.get(idSeleccionadoEnLista))
                startActivity(ventana)
                cargarCitas()
            }
            R.id.itemeliminar -> {
                var idEliminar = listaID.get(idSeleccionadoEnLista)
                AlertDialog.Builder(this)
                    .setTitle("ATENCIÓN")
                    .setMessage("¿ESTAS SEGURO DE QUE DESEAS ELIMINAR IDC: " + idEliminar + "?")
                    .setPositiveButton("ELIMINAR") { d, i ->
                        eliminar(idEliminar)
                    }
                    .setNeutralButton("NO") { d, i -> }
                    .show()
            }
        }
        idSeleccionadoEnLista = -1
        return true
    }

}
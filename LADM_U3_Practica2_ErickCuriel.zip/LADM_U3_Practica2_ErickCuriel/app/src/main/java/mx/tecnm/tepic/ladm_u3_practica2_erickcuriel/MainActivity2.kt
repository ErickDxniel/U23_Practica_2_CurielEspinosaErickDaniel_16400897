package mx.tecnm.tepic.ladm_u3_practica2_erickcuriel

import android.content.ContentValues
import android.database.sqlite.SQLiteException
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity2 : AppCompatActivity() {
    var baseDatos = BaseDatos(this, "CITA", null, 1)
    var id = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var extra = intent.extras
        id = extra?.getString("idactualizar")!!

        textViewIDC.setText(textViewIDC.text.toString() + "${id}")
        try {
            var base = baseDatos.readableDatabase

            var respuesta = base.query("CITA", arrayOf("LUGAR","HORA","FECHA","DESCRIPCION"),"IDC=?", arrayOf(id),null,null,null, null)

            if (respuesta.moveToFirst()) {
                editTextActualizarLugar.        setText(respuesta.getString(0))
                editTextActualizarHora.         setText(respuesta.getString(1))
                editTextActualizarFecha.        setText(respuesta.getString(2))
                editTextActualizarDescripcion.  setText(respuesta.getString(3))
            } else {
                mensaje("ERROR: NO SE ENCONTRO IDC!!!")
            }
            base.close()

        } catch (e: SQLiteException) {
            mensaje(e.message!!)
        }
        button5.setOnClickListener {
            actualizar(id)
        }

        button6.setOnClickListener {
            finish()
        }
    }

    private fun actualizar(id: String) {
        try {
            var trans = baseDatos.writableDatabase
            var valores = ContentValues()

            valores.put("LUGAR",          editTextActualizarLugar           .text.toString())
            valores.put("HORA",           editTextActualizarHora            .text.toString())
            valores.put("FECHA",          editTextActualizarFecha           .text.toString())
            valores.put("DESCRIPCION",    editTextActualizarDescripcion     .text.toString())

            var res = trans.update("CITA", valores, "IDC=?", arrayOf(id))
            if (res > 0) {
                mensaje("Se actualizó correctamente IDP: ${id}")
                finish()
            } else {
                mensaje("No se pudo actualizar IDC: ${id}")
            }
            trans.close()

        } catch (e:SQLiteException) {
            mensaje(e.message!!)
        }
    }

    private fun mensaje(s: String) {
        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage(s)
            .setPositiveButton("Ok") {d, i -> d.dismiss() }
    }
}